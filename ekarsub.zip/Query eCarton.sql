--untuk menampilkan semua table inner tag--
select * from [ECartonWebDB].[dbo].[InnerTag]

--untuk menampilkan semua table MsPartFG dimana partFGNO='AE272700-14907Z' --
select * from [ECartonWebDB].[dbo].[MsPartFG] where PartFGNo = 'AE272700-14907Z'


--untuk menampilkan semua table MsPartFG dimana BoxPartNo = 'AE989100-0261' --
select * from [ECartonWebDB].[dbo].[MsPartFG] where BoxPartNo = 'AE989100-0261'

--untuk menampilkan semua table MsPartFG dimana HeaderPartNo = 'AE989100-0261' --
select * from [ECartonWebDB].[dbo].[MsPackageSet] where HeaderPartNo = 'AE989100-0261'

--untuk menampilkan semua table MsGeneral --
select * from [ECartonWebDB].[dbo].[MsGeneral] 

--untuk menampilkan semua table PPLDaily --
select * FROM [ECartonWebDB].[dbo].[PPLDaily]

--untuk menampilkan semua table PPLDailyRaw --
select * FROM [ECartonWebDB].[dbo].[PPLDailyRaw]

--untuk menampilkan semua table PPLDailyAdditional --
select * FROM [ECartonWebDB].[dbo].[PPLDailyAdditional]

--untuk menampilkan semua table PPLMonthly --
select * FROM [ECartonWebDB].[dbo].[PPLMonthly]

--untuk menampilkan semua table PPLMonthlyRaw --
select * FROM [ECartonWebDB].[dbo].[PPLMonthlyRaw]

--untuk menampilkan semua table TmpGenerateDO --
select * FROM [ECartonWebDB].[dbo].[TmpGenerateDO]

--untuk menampilkan semua table DOHeader --
select * FROM [ECartonWebDB].[dbo].[DOHeader]

--untuk menampilkan semua table DODetail --
select * FROM [ECartonWebDB].[dbo].[DODetail]

--untuk menampilkan semua table MsSupplier --
select * FROM  [ECartonWebDB].[dbo].[MsSupplier]





--table induk dan anak pada database EcartonWebDB----
select ROW_NUMBER() OVER(ORDER BY d.SupplierId,a.PartNo) AS Id,a.PartNo,PartName,d.SupplierId,d.SupplierCode,d.SupplierName,d.DailyTimeOrder,d.ShipTypeCode ,a.PartitionQty,(substring(c.PRODY,1,4)+'-'+substring(c.PRODY,5,2)+'-'+substring(c.PRODY,7,2)) as ProdDate,isnull(e.StockQty,0)RealStock,((c.KANBAN/b.LotSize) * SetPcs)Ordered,((c.KANBAN/b.LotSize) * SetPcs)PPLQty,a.MaxStock,a.OrderTypeCode,f.GenName as OrderType,(((c.KANBAN/b.LotSize) * SetPcs)-isnull(e.StockQty,0))Balance,(ceiling((((c.KANBAN/b.LotSize) * SetPcs)-isnull(e.StockQty,0))/PartitionQty)*PartitionQty)DelivQty,((c.KANBAN) * 2)KANBAN
from [ECartonWebDB].[dbo].[MsPackageSet] a
inner join MsPartFG b on a.HeaderPartNo = b.BoxPartNo
inner join PPLDailyRaw c on b.PartFGNo = c.PRTNO
inner join MsSupplier d on d.SupplierId = a.SupplierId
left join InitialStock e on e.PartNo  = a.HeaderPartNo
inner join MsGeneral f on f.GenCode = a.OrderTypeCode
order by d.SupplierId,a.PartNo asc;



---(c.KANBAN/b.LotSize)jumlah_lot---


--UNION TABLE----
--fungsi UNION untuk mengabungkan table lain dengan lainnya dengan data yang masuk ke table utama--
select distinct TrayPartNo from MsPartFG
union
select distinct VCIPartNo from MsPartFG
union 
select distinct PolysheetPartNo  from MsPartFG
union
select distinct PalettePartNo  from MsPartFG


--table dengan part no----
select * from [ECartonWebDB].[dbo].[MsPartFG] a
inner join PPLDailyRaw b on a.PartFGNo = b.PRTNO

--table dengan jumlah qty---
select * from [ECartonWebDB].[dbo].[MsPartFG] a
inner join PPLDailyRaw b on a.LotSize = b.KANBAN
inner join PPLDaily c on a.LotSize = c.Qty

--(ceiling((((c.KANBAN/fg.LotSize) * SetPcs)-isnull(e.StockQty,0))/ps.PartitionQty)*ps.PartitionQty)



---ekarsub procedure untuk delivery order---
select ROW_NUMBER() OVER(ORDER BY SupplierId,PartNo)AS Id,* from (select distinct a.PartNo,PartName,d.SupplierId,d.SupplierCode,d.SupplierName,d.DailyTimeOrder,d.ShipTypeCode ,a.PartitionQty,(substring(c.PRODY,1,4)+'-'+substring(c.PRODY,5,2)+'-'+substring(c.PRODY,7,2)) as ProdDate,isnull(e.StockQty,0)RealStock,((c.KANBAN/b.LotSize) * SetPcs)Ordered,((c.KANBAN/b.LotSize) * SetPcs)PPLQty,a.MaxStock,a.OrderTypeCode,f.GenName as OrderType,(((c.KANBAN/b.LotSize) * SetPcs)-isnull(e.StockQty,0))Balance,IIF(f.GenName='PPL', (c.KANBAN/b.LotSize) * SetPcs, a.MinStock)DelivQty
		
from [ECartonWebDB].[dbo].[MsPackageSet] a
inner join MsPartFG b on a.HeaderPartNo = b.BoxPartNo
inner join PPLDailyRaw c on b.PartFGNo = c.PRTNO
inner join MsSupplier d on d.SupplierId = a.SupplierId
left join InitialStock e on e.PartNo  = a.HeaderPartNo
inner join MsGeneral f on f.GenCode = a.OrderTypeCode
inner join PPLDaily g on g.PartFGId = b.PartFGId
where IsActive=1

union all

---table untuk union TRAY Part no---
select distinct ps.PartNo,ps.PartName,ps.SupplierId,SupplierCode,SupplierName,DailyTimeOrder,ShipTypeCode,ps.PartitionQty,(substring(c.PRODY,1,4)+'-'+substring(c.PRODY,5,2)+'-'+substring(c.PRODY,7,2)) as ProdDate,isnull(e.StockQty,0)RealStock,((c.KANBAN/fg.LotSize) * SetPcs)Ordered,((c.KANBAN/fg.LotSize) * SetPcs)PPLQty,ps.MaxStock,ps.OrderTypeCode,f.GenName as OrderType,(((c.KANBAN/fg.LotSize) * SetPcs)-isnull(e.StockQty,0))Balance,IIF(f.GenName='PPL', (c.KANBAN/fg.LotSize) * SetPcs, ps.MinStock)DelivQty
		from PPLDaily ppl
		inner join MsPartFG fg on ppl.PartFGId=fg.PartFGId
		inner join (
			select distinct PartNo,PartName,SupplierId,SetPcs,OrdPercent,HeaderPartNo,OrderTypeCode,PartitionQty,MaxStock,MinStock from MsPackageSet where IsActive=1
		) ps on fg.TrayPartNo=ps.PartNo
		left join MsSupplier d on d.SupplierId = ps.SupplierId
		left join InitialStock e on e.PartNo  = fg.TrayPartNo
		left join MsGeneral f on f.GenCode = ps.OrderTypeCode
		inner join PPLDailyRaw c on fg.PartFGNo = c.PRTNO
		--WHERE isnull(e.StockQty,0)<=PS.MinStock


union all

		
---table untuk union VCI Part No---
select distinct ps.PartNo,ps.PartName,ps.SupplierId,SupplierCode,SupplierName,DailyTimeOrder,ShipTypeCode,ps.PartitionQty,(substring(c.PRODY,1,4)+'-'+substring(c.PRODY,5,2)+'-'+substring(c.PRODY,7,2)) as ProdDate,isnull(e.StockQty,0)RealStock,((c.KANBAN/fg.LotSize) * SetPcs)Ordered,((c.KANBAN/fg.LotSize) * SetPcs)PPLQty,ps.MaxStock,ps.OrderTypeCode,f.GenName as OrderType,(((c.KANBAN/fg.LotSize) * SetPcs)-isnull(e.StockQty,0))Balance,IIF(f.GenName='PPL', (c.KANBAN/fg.LotSize) * SetPcs, ps.MinStock)DelivQty
		from PPLDaily ppl
		inner join MsPartFG fg on ppl.PartFGId=fg.PartFGId
		inner join (
			select distinct PartNo,PartName,SupplierId,SetPcs,OrdPercent,HeaderPartNo,OrderTypeCode,PartitionQty,MaxStock,MinStock from MsPackageSet where IsActive=1
		) ps on fg.VCIPartNo=ps.PartNo
		left join MsSupplier d on d.SupplierId = ps.SupplierId
		left join InitialStock e on e.PartNo  = fg.VCIPartNo
		left join MsGeneral f on f.GenCode = ps.OrderTypeCode
		inner join PPLDailyRaw c on fg.PartFGNo = c.PRTNO
		--WHERE isnull(e.StockQty,0)<=PS.MinStock

union all
		
---table untuk union PolySheet part No---
select distinct ps.PartNo,ps.PartName,ps.SupplierId,SupplierCode,SupplierName,DailyTimeOrder,ShipTypeCode,ps.PartitionQty,(substring(c.PRODY,1,4)+'-'+substring(c.PRODY,5,2)+'-'+substring(c.PRODY,7,2)) as ProdDate,isnull(e.StockQty,0)RealStock,((c.KANBAN/fg.LotSize) * SetPcs)Ordered,((c.KANBAN/fg.LotSize) * SetPcs)PPLQty,ps.MaxStock,ps.OrderTypeCode,f.GenName as OrderType,(((c.KANBAN/fg.LotSize) * SetPcs)-isnull(e.StockQty,0))Balance,IIF(f.GenName='PPL', (c.KANBAN/fg.LotSize) * SetPcs, ps.MinStock)DelivQty
		from PPLDaily ppl
		inner join MsPartFG fg on ppl.PartFGId=fg.PartFGId
		inner join (
			select distinct PartNo,PartName,SupplierId,SetPcs,OrdPercent,HeaderPartNo,OrderTypeCode,PartitionQty,MaxStock,MinStock from MsPackageSet where IsActive=1
		) ps on fg.PolysheetPartNo=ps.PartNo
		left join MsSupplier d on d.SupplierId = ps.SupplierId
		left join InitialStock e on e.PartNo  = fg.PolysheetPartNo
		left join MsGeneral f on f.GenCode = ps.OrderTypeCode
		inner join PPLDailyRaw c on fg.PartFGNo = c.PRTNO
		--WHERE  isnull(e.StockQty,0)<=PS.MinStock

union all

---table untuk union Palette part No---
select distinct ps.PartNo,ps.PartName,ps.SupplierId,SupplierCode,SupplierName,DailyTimeOrder,ShipTypeCode,ps.PartitionQty,(substring(c.PRODY,1,4)+'-'+substring(c.PRODY,5,2)+'-'+substring(c.PRODY,7,2)) as ProdDate,isnull(e.StockQty,0)RealStock,((c.KANBAN/fg.LotSize) * SetPcs)Ordered,((c.KANBAN/fg.LotSize) * SetPcs)PPLQty,ps.MaxStock,ps.OrderTypeCode,f.GenName as OrderType,(((c.KANBAN/fg.LotSize) * SetPcs)-isnull(e.StockQty,0))Balance,IIF(f.GenName='PPL', (c.KANBAN/fg.LotSize) * SetPcs, ps.MinStock)DelivQty
		from PPLDaily ppl
		inner join MsPartFG fg on ppl.PartFGId=fg.PartFGId
		inner join (
			select distinct PartNo,PartName,SupplierId,SetPcs,OrdPercent,HeaderPartNo,OrderTypeCode,PartitionQty,MaxStock,MinStock from MsPackageSet where IsActive=1
		) ps on fg.PalettePartNo=ps.PartNo
		left join MsSupplier d on d.SupplierId = ps.SupplierId
		left join InitialStock e on e.PartNo  = fg.PalettePartNo
		left join MsGeneral f on f.GenCode = ps.OrderTypeCode
		inner join PPLDailyRaw c on fg.PartFGNo = c.PRTNO
		--WHERE isnull(e.StockQty,0)<=PS.MinStock
)DO




select * FROM [ECartonWebDB].[dbo].[TmpGenerateDO];


-- untuk menghapus TmpGenerateDO--
delete from TmpGenerateDO

-- untuk menghapus DOHeader--
delete from DOHeader

-- untuk menghapus DODetail--
delete from DODetail

-- untuk menghapus PPLDailyRaw--
delete from PPLDailyRaw

-- untuk menghapus PPLDaily--
delete from PPLDaily
