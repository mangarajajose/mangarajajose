---ekarsub procedure untuk delivery order---
select ROW_NUMBER() OVER(ORDER BY SupplierId,PartNo)AS Id,* from (select distinct a.PartNo,PartName,d.SupplierId,d.SupplierCode,d.SupplierName,d.DailyTimeOrder,d.ShipTypeCode ,a.PartitionQty,(substring(c.PRODY,1,4)+'-'+substring(c.PRODY,5,2)+'-'+substring(c.PRODY,7,2)) as ProdDate,isnull(e.StockQty,0)RealStock,((c.KANBAN/b.LotSize) * SetPcs)Ordered,((c.KANBAN/b.LotSize) * SetPcs)PPLQty,a.MaxStock,a.OrderTypeCode,f.GenName as OrderType,(((c.KANBAN/b.LotSize) * SetPcs)-isnull(e.StockQty,0))Balance,IIF(f.GenName='PPL', (c.KANBAN/b.LotSize) * SetPcs, a.MinStock)DelivQty
		
from [ECartonWebDB].[dbo].[MsPackageSet] a
inner join MsPartFG b on a.HeaderPartNo = b.BoxPartNo
inner join PPLDailyRaw c on b.PartFGNo = c.PRTNO
inner join MsSupplier d on d.SupplierId = a.SupplierId
left join InitialStock e on e.PartNo  = a.HeaderPartNo
inner join MsGeneral f on f.GenCode = a.OrderTypeCode
inner join PPLDaily g on g.PartFGId = b.PartFGId
where IsActive=1

union all

---table untuk union TRAY Part no---
select distinct ps.PartNo,ps.PartName,ps.SupplierId,SupplierCode,SupplierName,DailyTimeOrder,ShipTypeCode,ps.PartitionQty,(substring(c.PRODY,1,4)+'-'+substring(c.PRODY,5,2)+'-'+substring(c.PRODY,7,2)) as ProdDate,isnull(e.StockQty,0)RealStock,((c.KANBAN/fg.LotSize) * SetPcs)Ordered,((c.KANBAN/fg.LotSize) * SetPcs)PPLQty,ps.MaxStock,ps.OrderTypeCode,f.GenName as OrderType,(((c.KANBAN/fg.LotSize) * SetPcs)-isnull(e.StockQty,0))Balance,IIF(f.GenName='PPL', (c.KANBAN/fg.LotSize) * SetPcs, ps.MinStock)DelivQty
		from PPLDaily ppl
		inner join MsPartFG fg on ppl.PartFGId=fg.PartFGId
		inner join (
			select distinct PartNo,PartName,SupplierId,SetPcs,OrdPercent,HeaderPartNo,OrderTypeCode,PartitionQty,MaxStock,MinStock from MsPackageSet where IsActive=1
		) ps on fg.TrayPartNo=ps.PartNo
		left join MsSupplier d on d.SupplierId = ps.SupplierId
		left join InitialStock e on e.PartNo  = fg.TrayPartNo
		left join MsGeneral f on f.GenCode = ps.OrderTypeCode
		inner join PPLDailyRaw c on fg.PartFGNo = c.PRTNO
		--WHERE isnull(e.StockQty,0)<=PS.MinStock


union all

		
---table untuk union VCI Part No---
select distinct ps.PartNo,ps.PartName,ps.SupplierId,SupplierCode,SupplierName,DailyTimeOrder,ShipTypeCode,ps.PartitionQty,(substring(c.PRODY,1,4)+'-'+substring(c.PRODY,5,2)+'-'+substring(c.PRODY,7,2)) as ProdDate,isnull(e.StockQty,0)RealStock,((c.KANBAN/fg.LotSize) * SetPcs)Ordered,((c.KANBAN/fg.LotSize) * SetPcs)PPLQty,ps.MaxStock,ps.OrderTypeCode,f.GenName as OrderType,(((c.KANBAN/fg.LotSize) * SetPcs)-isnull(e.StockQty,0))Balance,IIF(f.GenName='PPL', (c.KANBAN/fg.LotSize) * SetPcs, ps.MinStock)DelivQty
		from PPLDaily ppl
		inner join MsPartFG fg on ppl.PartFGId=fg.PartFGId
		inner join (
			select distinct PartNo,PartName,SupplierId,SetPcs,OrdPercent,HeaderPartNo,OrderTypeCode,PartitionQty,MaxStock,MinStock from MsPackageSet where IsActive=1
		) ps on fg.VCIPartNo=ps.PartNo
		left join MsSupplier d on d.SupplierId = ps.SupplierId
		left join InitialStock e on e.PartNo  = fg.VCIPartNo
		left join MsGeneral f on f.GenCode = ps.OrderTypeCode
		inner join PPLDailyRaw c on fg.PartFGNo = c.PRTNO
		--WHERE isnull(e.StockQty,0)<=PS.MinStock

union all
		
---table untuk union PolySheet part No---
select distinct ps.PartNo,ps.PartName,ps.SupplierId,SupplierCode,SupplierName,DailyTimeOrder,ShipTypeCode,ps.PartitionQty,(substring(c.PRODY,1,4)+'-'+substring(c.PRODY,5,2)+'-'+substring(c.PRODY,7,2)) as ProdDate,isnull(e.StockQty,0)RealStock,((c.KANBAN/fg.LotSize) * SetPcs)Ordered,((c.KANBAN/fg.LotSize) * SetPcs)PPLQty,ps.MaxStock,ps.OrderTypeCode,f.GenName as OrderType,(((c.KANBAN/fg.LotSize) * SetPcs)-isnull(e.StockQty,0))Balance,IIF(f.GenName='PPL', (c.KANBAN/fg.LotSize) * SetPcs, ps.MinStock)DelivQty
		from PPLDaily ppl
		inner join MsPartFG fg on ppl.PartFGId=fg.PartFGId
		inner join (
			select distinct PartNo,PartName,SupplierId,SetPcs,OrdPercent,HeaderPartNo,OrderTypeCode,PartitionQty,MaxStock,MinStock from MsPackageSet where IsActive=1
		) ps on fg.PolysheetPartNo=ps.PartNo
		left join MsSupplier d on d.SupplierId = ps.SupplierId
		left join InitialStock e on e.PartNo  = fg.PolysheetPartNo
		left join MsGeneral f on f.GenCode = ps.OrderTypeCode
		inner join PPLDailyRaw c on fg.PartFGNo = c.PRTNO
		--WHERE  isnull(e.StockQty,0)<=PS.MinStock

union all

---table untuk union Palette part No---
select distinct ps.PartNo,ps.PartName,ps.SupplierId,SupplierCode,SupplierName,DailyTimeOrder,ShipTypeCode,ps.PartitionQty,(substring(c.PRODY,1,4)+'-'+substring(c.PRODY,5,2)+'-'+substring(c.PRODY,7,2)) as ProdDate,isnull(e.StockQty,0)RealStock,((c.KANBAN/fg.LotSize) * SetPcs)Ordered,((c.KANBAN/fg.LotSize) * SetPcs)PPLQty,ps.MaxStock,ps.OrderTypeCode,f.GenName as OrderType,(((c.KANBAN/fg.LotSize) * SetPcs)-isnull(e.StockQty,0))Balance,IIF(f.GenName='PPL', (c.KANBAN/fg.LotSize) * SetPcs, ps.MinStock)DelivQty
		from PPLDaily ppl
		inner join MsPartFG fg on ppl.PartFGId=fg.PartFGId
		inner join (
			select distinct PartNo,PartName,SupplierId,SetPcs,OrdPercent,HeaderPartNo,OrderTypeCode,PartitionQty,MaxStock,MinStock from MsPackageSet where IsActive=1
		) ps on fg.PalettePartNo=ps.PartNo
		left join MsSupplier d on d.SupplierId = ps.SupplierId
		left join InitialStock e on e.PartNo  = fg.PalettePartNo
		left join MsGeneral f on f.GenCode = ps.OrderTypeCode
		inner join PPLDailyRaw c on fg.PartFGNo = c.PRTNO
		--WHERE isnull(e.StockQty,0)<=PS.MinStock
)DO




		----ROW_NUMBER() OVER(ORDER BY ppl.SupplierId,ps.PartNo)AS Id,---